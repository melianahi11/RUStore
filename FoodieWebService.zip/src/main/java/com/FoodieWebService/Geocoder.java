package com.FoodieWebService;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Geocoder {

	private String GeocodeSync(String address) throws IOException, InterruptedException {

		HttpClient httpClient = HttpClient.newHttpClient();

		String encodedAddress = URLEncoder.encode(address,"UTF-8");

		String requestUri = StringConstants.GEOCODER_RESOURCE + "?q=" + encodedAddress + "&api_key=" + StringConstants.GEOCODER_API_KEY;

		HttpRequest request = HttpRequest.newBuilder().GET().uri(URI.create(requestUri))
				.timeout(Duration.ofMillis(2000)).build();

		HttpResponse response = httpClient.send(request,
				HttpResponse.BodyHandlers.ofString());

		return (String) response.body();
	}

	public static Geocode getGeocode(String address) {
		Geocode geo = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			Geocoder geocoder = new Geocoder();

			String response = geocoder.GeocodeSync(address);
			if(response != null) {
				JsonNode responseJsonNode = mapper.readTree(response);

				JsonNode item = responseJsonNode.get("results").get(0);

				String rAddress = item.get("formatted_address").asText();
				double rLat = item.get("location").get("lat").asDouble();
				double rLng = item.get("location").get("lng").asDouble();

				geo = new Geocode(rAddress, rLat, rLng);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return geo;
	}

}
