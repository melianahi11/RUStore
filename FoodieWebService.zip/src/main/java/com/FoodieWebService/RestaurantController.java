package com.FoodieWebService;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestaurantController {
	
	@GetMapping("/restaurant")
	public ResponseEntity<Object> restaurant(@RequestParam(value = "address") String address) {
		Map<String,Object> response = new HashMap<>();
		
		Geocode geo = Geocoder.getGeocode(address);
		
		if(geo == null) {
			response.put("timestamp", getServerTime());
			response.put("status", 500);
			response.put("error", "Internal Server Error");
			response.put("path", "/restaurant");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
		
		List<Restaurant> restaurants = Yelper.getRestaurants(geo.getLatitude(), geo.getLongitude());
		
		if(restaurants == null) {
			response.put("timestamp", getServerTime());
			response.put("status", 500);
			response.put("error", "Internal Server Error");
			response.put("path", "/restaurant");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
		
		response.put("restaurants", restaurants);
		
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
	private String getServerTime() {
	    Calendar calendar = Calendar.getInstance();
	    SimpleDateFormat dateFormat = new SimpleDateFormat(
	        "EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
	    dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
	    return dateFormat.format(calendar.getTime());
	}
}
