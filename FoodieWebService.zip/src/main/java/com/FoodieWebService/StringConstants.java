package com.FoodieWebService;

public class StringConstants {
	public static final String GEOCODER_RESOURCE = "https://api.geocod.io/v1.7/geocode";
	public static final String GEOCODER_API_KEY = "698d293862826d87ae777fd2f29a7283ff3a8d7";
	
	public static final String YELP_RESOURCE = "https://api.yelp.com/v3/businesses/search";
	public static final String YELP_API_KEY = "ckHQ3TVTnEj6axJ4WTtyku6WtGX3FmsmAiCBPUXpFvzRCB381-bveJLjXo1SMDdrPvGXJW5T-_lXG7CB_nlZ6s1qXrNqNHxfUIzpgo7aUxN-sImcI83CGqTsxbJyY3Yx";
}
