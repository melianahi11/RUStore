package com.FoodieWebService;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Yelper {

	private String YelpSync(double lat, double lng) throws IOException, InterruptedException {

		HttpClient httpClient = HttpClient.newHttpClient();

		String requestUri = StringConstants.YELP_RESOURCE + "?latitude=" + lat + "&longitude=" + lng;

		HttpRequest geocodingRequest = HttpRequest.newBuilder().GET().header("Authorization", "Bearer " + StringConstants.YELP_API_KEY).uri(URI.create(requestUri))
				.timeout(Duration.ofMillis(2000)).build();

		HttpResponse geocodingResponse = httpClient.send(geocodingRequest,
				HttpResponse.BodyHandlers.ofString());

		return (String) geocodingResponse.body();
	}

	public static List<Restaurant> getRestaurants(double lat, double lng) {
		List<Restaurant> list = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			Yelper yelper = new Yelper();

			String response = yelper.YelpSync(lat, lng);
			
			if(response != null) {
				list = new ArrayList<>();
				
				JsonNode responseJsonNode = mapper.readTree(response);

				JsonNode items = responseJsonNode.get("businesses");

				for(JsonNode item: items) {
					String name = item.get("name").asText();

					String address = "";

					JsonNode displayAddress = item.get("location").get("display_address");
					for(JsonNode line: displayAddress) {
						address = address + ", " + line.asText();
					}
					address = address.substring(2);


					double rating = item.get("rating").asDouble();

					Restaurant restaurant = new Restaurant(name, address, rating);

					list.add(restaurant);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

}
